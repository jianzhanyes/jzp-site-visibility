<?php
/**
 * 卸载清理
 */
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

delete_option('jzp_site_visibility_settings');
delete_option('jzp_site_visibility_internal_key');
delete_transient('jzp_site_visibility_update_info');