<?php
/**
 * Plugin Name:       JZP Site Visibility
 * Plugin URI:        https://www.jianzhanpress.com/?p=4633
 * Description:       控制网站前台可见性，支持在线/离线模式切换，离线时向访客显示维护提示。
 * Version:           1.3.0
 * Author:            Jianzhanpress.com
 * Author URI:        https://www.Jianzhanpress.com
 * Update URI:        https://wordpress.xz.cn
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       jzp-site-visibility
 * Requires at least: 5.0
 * Requires PHP:      7.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// 插件主文件路径常量
if (!defined('JZP_SITE_VISIBILITY_FILE')) {
    define('JZP_SITE_VISIBILITY_FILE', __FILE__);
}

/* ============================================================
 * 插件自托管更新
 * ============================================================ */

// 自托管更新服务器的 JSON 接口地址
if (!defined('JZP_SITE_VISIBILITY_UPDATE_API')) {
    define('JZP_SITE_VISIBILITY_UPDATE_API', 'https://wordpress.xz.cn/plugins/wp-update/jzp-site-visibility/update.json');
}

// 缓存 key（带插件前缀，避免冲突）
if (!defined('JZP_SITE_VISIBILITY_UPDATE_CACHE_KEY')) {
    define('JZP_SITE_VISIBILITY_UPDATE_CACHE_KEY', 'jzp_site_visibility_update_info');
}

// 远端拉取失败时的标记（避免用 null，因为 set_transient 存 null 等于删除）
if (!defined('JZP_SITE_VISIBILITY_UPDATE_FAIL_FLAG')) {
    define('JZP_SITE_VISIBILITY_UPDATE_FAIL_FLAG', 'jzp_sv_fail');
}

/**
 * 获取缓存有效期（秒），默认 12 小时，可用过滤器覆盖
 */
if (!function_exists('jzp_site_visibility_get_update_cache_ttl')) {
    function jzp_site_visibility_get_update_cache_ttl()
    {
        return (int) apply_filters('jzp_site_visibility_update_cache_ttl', 12 * HOUR_IN_SECONDS);
    }
}

/**
 * 网站可见性模块
 */
class JZP_Site_Visibility
{
    /**
     * 选项名称
     */
    const OPTION_NAME = 'jzp_site_visibility_settings';

    /**
     * 内部请求密钥选项名
     */
    const KEY_OPTION_NAME = 'jzp_site_visibility_internal_key';

    /**
     * 请求头名称（内部请求放行标识）
     */
    const INTERNAL_HEADER = 'X-JZP-Internal';

    /**
     * 构造函数
     */
    public function __construct()
    {
        // 前端拦截（优先级 1，尽量早执行）
        add_action('template_redirect', [$this, 'front_intercept'], 1);

        // 后台管理
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_notices', [$this, 'admin_notice']);

        // 手动强制检查更新
        add_action('admin_init', [$this, 'maybe_force_check']);

        // 自托管更新
        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_for_update']);
        add_filter('plugins_api', [$this, 'plugin_info'], 20, 3);
        add_action('upgrader_process_complete', [$this, 'clear_update_cache'], 10, 2);
        add_filter('plugin_action_links_' . plugin_basename(JZP_SITE_VISIBILITY_FILE), [$this, 'action_links']);
    }

    /* ============================================================
     * 设置读写
     * ============================================================ */

    /**
     * 获取设置
     *
     * @return array
     */
    public function get_settings()
    {
        $defaults = [
            'site_mode'    => 'online',
            'offline_text' => '站点暂时离线维护，请稍后再来访问。',
        ];

        return wp_parse_args(get_option(self::OPTION_NAME, []), $defaults);
    }

    /**
     * 获取内部请求密钥（首次调用时自动生成并保存）
     *
     * @return string
     */
    public function get_internal_key()
    {
        $key = get_option(self::KEY_OPTION_NAME);

        if (empty($key) || !is_string($key)) {
            $key = wp_generate_password(48, false, false);
            update_option(self::KEY_OPTION_NAME, $key, false);
        }

        return $key;
    }

    /* ============================================================
     * 前端拦截
     * ============================================================ */

    /**
     * 前端拦截
     */
    public function front_intercept()
    {
        $opts = $this->get_settings();

        // 在线模式直接放行
        if ($opts['site_mode'] !== 'offline') {
            return;
        }

        // 放行后台内部请求（整站静态化、内部抓取等），使用密钥校验
        if ($this->is_valid_internal_request()) {
            return;
        }

        // 管理员放行
        if (current_user_can('manage_options')) {
            return;
        }

        // 离线提示 —— 标题使用网站名称，状态码 503
        wp_die(
            '<h2>' . esc_html($opts['offline_text']) . '</h2>',
            esc_html(get_bloginfo('name')),
            ['response' => 503]
        );
    }

    /**
     * 判断当前请求是否为合法的内部请求
     *
     * @return bool
     */
    private function is_valid_internal_request()
    {
        if (empty($_SERVER['HTTP_X_JZP_INTERNAL'])) {
            return false;
        }

        $provided = sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_JZP_INTERNAL'] ) );
        $expected = (string) $this->get_internal_key();

        // 使用 hash_equals 防止时序攻击
        return hash_equals($expected, $provided);
    }

    /**
     * 供其他代码调用的内部请求辅助方法
     *
     * 用法示例：
     *   $response = JZP_Site_Visibility::internal_request( home_url('/') );
     *
     * @param string $url
     * @param array  $args
     * @return array|WP_Error
     */
    public static function internal_request($url, $args = [])
    {
        $instance = self::instance();

        $headers = isset($args['headers']) && is_array($args['headers'])
            ? $args['headers']
            : [];

        $headers[self::INTERNAL_HEADER] = $instance->get_internal_key();

        $args['headers'] = $headers;
        $args['timeout'] = isset($args['timeout']) ? $args['timeout'] : 15;

        return wp_remote_get($url, $args);
    }

    /**
     * 单例实例
     *
     * @return JZP_Site_Visibility
     */
    private static function instance()
    {
        static $instance = null;
        if ($instance === null) {
            $instance = new self();
        }
        return $instance;
    }

    /* ============================================================
     * 后台菜单与设置
     * ============================================================ */

    /**
     * 添加后台菜单
     */
    public function add_admin_menu()
    {
        add_options_page(
            '网站可见性设置',
            '网站可见性',
            'manage_options',
            'jzp-site-visibility',
            [$this, 'render_settings_page']
        );
    }

    /**
     * 注册设置
     */
    public function register_settings()
    {
        register_setting(
            'jzp_site_visibility_group',
            self::OPTION_NAME,
            [
                'type'              => 'array',
                'sanitize_callback' => [$this, 'sanitize_settings'],
                'default'           => [
                    'site_mode'    => 'online',
                    'offline_text' => '站点暂时离线维护，请稍后再来访问。',
                ],
            ]
        );

        add_settings_section(
            'jzp_site_visibility_main',
            '基本设置',
            [$this, 'render_section_intro'],
            'jzp-site-visibility'
        );

        add_settings_field(
            'site_mode',
            '站点模式',
            [$this, 'render_field_site_mode'],
            'jzp-site-visibility',
            'jzp_site_visibility_main'
        );

        add_settings_field(
            'offline_text',
            '离线提示文字',
            [$this, 'render_field_offline_text'],
            'jzp-site-visibility',
            'jzp_site_visibility_main'
        );
    }

    /**
     * 清理设置数据
     *
     * @param mixed $input
     * @return array
     */
    public function sanitize_settings($input)
    {
        $defaults = [
            'site_mode'    => 'online',
            'offline_text' => '站点暂时离线维护，请稍后再来访问。',
        ];

        $output = [];
        $input  = is_array($input) ? $input : [];

        $output['site_mode'] = (isset($input['site_mode']) && $input['site_mode'] === 'offline')
            ? 'offline'
            : 'online';

        if (isset($input['offline_text'])) {
            $output['offline_text'] = sanitize_textarea_field($input['offline_text']);
        } else {
            $output['offline_text'] = $defaults['offline_text'];
        }

        return $output;
    }

    /**
     * 设置区块说明
     */
    public function render_section_intro()
    {
        echo '<p>控制网站前台是否对访客可见。管理员始终可以正常访问前台。</p>';
    }

    /**
     * 渲染站点模式字段
     */
    public function render_field_site_mode()
    {
        $opts = $this->get_settings();
        ?>
        <fieldset>
            <label>
                <input type="radio" name="<?php echo esc_attr(self::OPTION_NAME); ?>[site_mode]" value="online" <?php checked($opts['site_mode'], 'online'); ?> />
                在线（正常访问）
            </label>
            <br />
            <label>
                <input type="radio" name="<?php echo esc_attr(self::OPTION_NAME); ?>[site_mode]" value="offline" <?php checked($opts['site_mode'], 'offline'); ?> />
                离线（仅管理员可访问）
            </label>
        </fieldset>
        <?php
    }

    /**
     * 渲染离线提示文字字段
     */
    public function render_field_offline_text()
    {
        $opts = $this->get_settings();
        ?>
        <textarea
            name="<?php echo esc_attr(self::OPTION_NAME); ?>[offline_text]"
            rows="4"
            cols="60"
            class="large-text"
        ><?php echo esc_textarea($opts['offline_text']); ?></textarea>
        <p class="description">离线模式下，访客将看到此提示内容。</p>
        <?php
    }

    /* ============================================================
     * 设置页面（Tab 切换）
     * ============================================================ */

    /**
     * 渲染设置页面（带 Tab 切换）
     */
    public function render_settings_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $opts = $this->get_settings();

        $tab_param   = filter_input( INPUT_GET, 'tab', FILTER_DEFAULT );
        $current_tab = $tab_param ? sanitize_key( $tab_param ) : 'settings';

        $tabs = [
            'settings' => '设置',
            'about'    => '关于插件',
            'help'     => '使用帮助',
        ];
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

            <?php if ($opts['site_mode'] === 'offline') : ?>
                <div class="notice notice-warning inline">
                    <p><strong>当前站点处于离线模式</strong>，仅管理员可访问前台。</p>
                </div>
            <?php endif; ?>

            <h2 class="nav-tab-wrapper">
                <?php foreach ($tabs as $key => $label) : ?>
                    <a href="<?php echo esc_url(add_query_arg(['page' => 'jzp-site-visibility', 'tab' => $key], admin_url('options-general.php'))); ?>"
                       class="nav-tab <?php echo $current_tab === $key ? 'nav-tab-active' : ''; ?>">
                        <?php echo esc_html($label); ?>
                    </a>
                <?php endforeach; ?>
            </h2>

            <div class="jzp-tab-content" style="margin-top:20px;">
                <?php
                switch ($current_tab) {
                    case 'about':
                        $this->render_tab_about();
                        break;
                    case 'help':
                        $this->render_tab_help();
                        break;
                    case 'settings':
                    default:
                        $this->render_tab_settings();
                        break;
                }
                ?>
            </div>
        </div>
        <?php
    }

    /**
     * Tab: 设置
     */
    private function render_tab_settings()
    {
        ?>
        <form action="options.php" method="post">
            <?php
            settings_fields('jzp_site_visibility_group');
            do_settings_sections('jzp-site-visibility');
            submit_button('保存设置');
            ?>
        </form>
        <?php
    }

    /**
     * Tab: 关于插件
     */
    private function render_tab_about()
    {
        $key = $this->get_internal_key();
        ?>
        <div class="card" style="max-width:720px;">
            <h2>关于 JZP 网站可见性</h2>
            <p>这是一个用于控制网站前台可见性的轻量插件，支持在线 / 离线模式一键切换。</p>
            <ul style="list-style:disc;padding-left:20px;">
                <li>版本：1.3.0</li>
                <li>作者：Jianzhanpress.com</li>
                <li>功能：离线维护、自定义提示文字、管理员放行、内部请求密钥放行、自托管更新</li>
            </ul>

            <h3>内部请求密钥</h3>
            <p>其他插件或主题代码在离线模式下抓取本站页面时，请在 HTTP 请求头中携带以下密钥，即可正常访问：</p>
            <p>
                <code style="display:inline-block;padding:6px 10px;background:#f1f1f1;border-radius:4px;">
                    <?php echo esc_html(self::INTERNAL_HEADER); ?>: <?php echo esc_html($key); ?>
                </code>
            </p>
            <p class="description">
                推荐使用插件内置的静态方法发起内部请求：<br />
                <code>JZP_Site_Visibility::internal_request( home_url('/') );</code>
            </p>
        </div>
        <?php
    }

    /**
     * Tab: 使用帮助
     */
    private function render_tab_help()
    {
        ?>
        <div class="card" style="max-width:720px;">
            <h2>使用帮助</h2>
            <ol style="padding-left:20px;">
                <li>进入「设置 &gt; 网站可见性」。</li>
                <li>在「设置」标签中选择「在线」或「离线」模式并保存。</li>
                <li>选择「离线」后，非管理员访客将看到维护提示。</li>
                <li>管理员登录状态下始终可以正常访问前台。</li>
                <li>如需自定义提示文字，直接修改「离线提示文字」字段即可。</li>
            </ol>

            <h3>内部请求放行</h3>
            <p>若站点启用了整站静态化、SEO 预抓取等需要"自己访问自己"的功能，请在请求头中加入与「关于插件」页面中显示的密钥一致的 <code>X-JZP-Internal</code> 头。或者直接在代码里调用：</p>
            <pre style="background:#f1f1f1;padding:10px;border-radius:4px;overflow:auto;">$response = JZP_Site_Visibility::internal_request( home_url('/') );
if ( ! is_wp_error( $response ) ) {
    $html = wp_remote_retrieve_body( $response );
}</pre>

            <h3>手动检查更新</h3>
            <p>进入「插件 &gt; 已安装的插件」，在 JZP Site Visibility 下方点击「检查更新」即可强制拉取远端最新版本信息。</p>
        </div>
        <?php
    }

    /* ============================================================
     * 后台提醒
     * ============================================================ */

    /**
     * 后台提醒
     */
    public function admin_notice()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $opts = $this->get_settings();
        if ($opts['site_mode'] !== 'offline') {
            return;
        }

        $screen = get_current_screen();
        if ($screen && $screen->id === 'settings_page_jzp-site-visibility') {
            return;
        }

        echo '<div class="notice notice-warning is-dismissible">';
        echo '<p><strong>JZP网站可见性：</strong>站点当前处于离线模式，访客无法访问前台。</p>';
        echo '</div>';
    }

    /* ============================================================
     * 自托管更新
     * ============================================================ */

    /**
     * 检查插件更新
     *
     * @param object $transient
     * @return object
     */
    public function check_for_update($transient)
    {
        if (empty($transient->checked)) {
            return $transient;
        }

        $plugin_file = plugin_basename(JZP_SITE_VISIBILITY_FILE);

        // 只有当前插件在检查列表中时才处理
        if (!isset($transient->checked[$plugin_file])) {
            return $transient;
        }

        // 本插件走自托管更新，移除 WordPress.org 可能返回的同名更新条目，
        // 确保更新源只有自托管服务器。
        if (isset($transient->response[$plugin_file])) {
            unset($transient->response[$plugin_file]);
        }

        $remote = $this->get_remote_info();

        if (!$remote || empty($remote->version)) {
            return $transient;
        }

        $current_version = $transient->checked[$plugin_file];

        if (version_compare($remote->version, $current_version, '>')) {
            $item = (object) [
                'id'           => isset($remote->id) ? $remote->id : $plugin_file,
                'slug'         => isset($remote->slug) ? $remote->slug : dirname($plugin_file),
                'plugin'       => $plugin_file,
                'new_version'  => $remote->version,
                'url'          => isset($remote->homepage) ? $remote->homepage : '',
                'package'      => isset($remote->download_url) ? $remote->download_url : '',
                'tested'       => isset($remote->tested) ? $remote->tested : '',
                'requires'     => isset($remote->requires) ? $remote->requires : '',
                'requires_php' => isset($remote->requires_php) ? $remote->requires_php : '',
                'icons'        => (array) (isset($remote->icons) ? $remote->icons : []),
                'banners'      => (array) (isset($remote->banners) ? $remote->banners : []),
            ];

            if (!empty($item->package)) {
                $transient->response[$plugin_file] = $item;
            }
        } else {
            // 无更新时放入 no_update，避免 WordPress 显示"未知"
            $transient->no_update[$plugin_file] = (object) [
                'id'          => $plugin_file,
                'slug'        => dirname($plugin_file),
                'plugin'      => $plugin_file,
                'new_version' => $current_version,
                'url'         => '',
                'package'     => '',
            ];
        }

        return $transient;
    }

    /**
     * 插件详情弹窗信息
     *
     * @param false|object|array $result
     * @param string             $action
     * @param object             $args
     * @return false|object|array
     */
    public function plugin_info($result, $action, $args)
    {
        if ($action !== 'plugin_information') {
            return $result;
        }

        $plugin_file = plugin_basename(JZP_SITE_VISIBILITY_FILE);
        $slug        = dirname($plugin_file);

        // 兼容多种目录名
        $allowed_slugs = [$slug, 'jzp-site-visibility'];

        if (!isset($args->slug) || !in_array($args->slug, $allowed_slugs, true)) {
            return $result;
        }

        $remote = $this->get_remote_info();

        if (!$remote) {
            return $result;
        }

        $info = (object) [
            'name'           => isset($remote->name) ? $remote->name : 'JZP Site Visibility',
            'slug'           => $slug,
            'version'        => isset($remote->version) ? $remote->version : '',
            'author'         => isset($remote->author) ? $remote->author : '',
            'author_profile' => isset($remote->author_homepage) ? $remote->author_homepage : '',
            'homepage'       => isset($remote->homepage) ? $remote->homepage : '',
            'requires'       => isset($remote->requires) ? $remote->requires : '',
            'tested'         => isset($remote->tested) ? $remote->tested : '',
            'requires_php'   => isset($remote->requires_php) ? $remote->requires_php : '',
            'downloaded'     => isset($remote->downloaded) ? $remote->downloaded : 0,
            'last_updated'   => isset($remote->last_updated) ? $remote->last_updated : '',
            'sections'       => (array) (isset($remote->sections) ? $remote->sections : []),
            'download_link'  => isset($remote->download_url) ? $remote->download_url : '',
            'banners'        => (array) (isset($remote->banners) ? $remote->banners : []),
            'icons'          => (array) (isset($remote->icons) ? $remote->icons : []),
        ];

        return $info;
    }

    /**
     * 获取远端更新信息（带缓存）
     *
     * 缓存策略：
     * - 成功：缓存对象 12 小时
     * - 失败：缓存字符串标记 10 分钟（避免频繁请求远端）
     *
     * @return object|false
     */
    private function get_remote_info()
    {
        $cached = get_transient(JZP_SITE_VISIBILITY_UPDATE_CACHE_KEY);

        // 命中缓存且是有效对象时直接返回
        if (is_object($cached)) {
            return $cached;
        }

        // 命中失败标记，短时间内不再重复请求
        if ($cached === JZP_SITE_VISIBILITY_UPDATE_FAIL_FLAG) {
            return false;
        }

        $response = wp_remote_get(
            JZP_SITE_VISIBILITY_UPDATE_API,
            [
                'timeout' => 15,
                'headers' => [
                    'Accept' => 'application/json',
                ],
            ]
        );

        // 网络异常：缓存失败标记
        if (is_wp_error($response)) {
            set_transient(
                JZP_SITE_VISIBILITY_UPDATE_CACHE_KEY,
                JZP_SITE_VISIBILITY_UPDATE_FAIL_FLAG,
                10 * MINUTE_IN_SECONDS
            );
            return false;
        }

        // 非 200：缓存失败标记
        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            set_transient(
                JZP_SITE_VISIBILITY_UPDATE_CACHE_KEY,
                JZP_SITE_VISIBILITY_UPDATE_FAIL_FLAG,
                10 * MINUTE_IN_SECONDS
            );
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body);

        // JSON 无效：缓存失败标记
        if (!is_object($data) || empty($data->version)) {
            set_transient(
                JZP_SITE_VISIBILITY_UPDATE_CACHE_KEY,
                JZP_SITE_VISIBILITY_UPDATE_FAIL_FLAG,
                10 * MINUTE_IN_SECONDS
            );
            return false;
        }

        // 成功：缓存对象
        set_transient(
            JZP_SITE_VISIBILITY_UPDATE_CACHE_KEY,
            $data,
            jzp_site_visibility_get_update_cache_ttl()
        );

        return $data;
    }

    /**
     * 插件更新完成后清除缓存
     *
     * @param WP_Upgrader $upgrader
     * @param array       $options
     */
    public function clear_update_cache($upgrader, $options)
    {
        if (
            isset($options['action'], $options['type']) &&
            $options['action'] === 'update' &&
            $options['type'] === 'plugin'
        ) {
            delete_transient(JZP_SITE_VISIBILITY_UPDATE_CACHE_KEY);
            delete_site_transient('update_plugins');
        }
    }

    /**
     * 插件列表中增加"检查更新"链接
     *
     * @param array $links
     * @return array
     */
    public function action_links($links)
    {
        $check_url = wp_nonce_url(
            add_query_arg(
                [
                    'jzp_sv_force_check' => '1',
                ],
                admin_url('plugins.php')
            ),
            'jzp_sv_force_check'
        );

        $links[] = '<a href="' . esc_url($check_url) . '">检查更新</a>';

        return $links;
    }

    /**
     * 手动强制检查更新（点击"检查更新"时清缓存并跳转）
     *
     * 关键：必须同时清除两层缓存
     * 1. 插件自身的 JSON 缓存 transient
     * 2. WordPress 的 site_transient('update_plugins')
     * 否则 wp_update_plugins() 会用旧缓存，不会重新请求
     */
    public function maybe_force_check()
    {
        if (
            isset($_GET['jzp_sv_force_check']) &&
            $_GET['jzp_sv_force_check'] === '1' &&
            current_user_can('update_plugins')
        ) {
            check_admin_referer('jzp_sv_force_check');

            // 1. 清插件自身 JSON 缓存
            delete_transient(JZP_SITE_VISIBILITY_UPDATE_CACHE_KEY);

            // 2. 清 WordPress 插件更新 transient（关键）
            delete_site_transient('update_plugins');

            // 3. 立即重新检查
            wp_update_plugins();

            wp_safe_redirect(admin_url('plugins.php'));
            exit;
        }
    }
}

// 初始化
new JZP_Site_Visibility();