=== JZP Site Visibility ===
Contributors: jianzhanpress
Tags: maintenance, offline, site-visibility, access-control
Requires at least: 5.0
Tested up to: 7.1
Requires PHP: 7.0
Stable tag: 1.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Control your site frontend visibility with one-click online/offline modes and a custom maintenance message for visitors.

== Description ==

JZP Site Visibility is a lightweight plugin that controls whether your site frontend is visible to visitors.

= Features =

* One-click switch between online and offline modes
* Shows a custom maintenance message to visitors in offline mode (HTTP 503)
* Administrators always keep full access to the frontend
* Internal request key support for static site generation and SEO crawling
* Self-hosted update checking

= Internal request passthrough =

If your site uses full-site static generation, SEO pre-crawling, or any feature that needs to request your own site while it is offline, send the `X-JZP-Internal` header with the key shown on the plugin's About tab, or use the built-in helper method:

`JZP_Site_Visibility::internal_request( home_url('/') );`

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the Plugins screen in WordPress.
3. Go to Settings > Site Visibility to configure the plugin.

== Frequently Asked Questions ==

= Are administrators blocked in offline mode? =

No. Users with the `manage_options` capability can always access the frontend normally.

= How do I customize the offline message? =

Edit the offline notice text field on the Settings > Site Visibility screen.

== Changelog ==

= 1.3.0 =
* Add online/offline mode switch with a custom maintenance message.
* Add internal request key passthrough for trusted internal HTTP requests.
* Add self-hosted update checking with a manual "Check update" link.

== Upgrade Notice ==

= 1.3.0 =
Adds internal request passthrough and self-hosted update checking.
